import { Controller } from "./controller.js";

let controller = new Controller();

export {
    controller
}